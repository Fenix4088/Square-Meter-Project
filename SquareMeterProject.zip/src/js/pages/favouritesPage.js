export default function () {
    const markup = `<div class="container"><h1>FavouritesPage</h1></div>`;
    document.querySelector("#app").innerHTML = markup;
}
