export default function () {
    document.querySelector("#app").innerHTML = "";
    const markup = `<div class="container"><h1>ErrorPage</h1></div>`;
    document.querySelector("#app").innerHTML = markup;
}
