export default function () {
    const markup = `<div class="container"><h1>BidsPage</h1></div>`;
    document.querySelector("#app").innerHTML = markup;
}
