import filter from "./../filter/filterController.js";

export default function (state) {
    // Запуск формы фильтра
    filter(state);
}
